def main(context):
    return context.res.json({"message": "Hello World"})
